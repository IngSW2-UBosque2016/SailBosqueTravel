
module.exports = {

	attributes: {
	id:{

	    type: 'integer',
		primarykey:true,
	    unique: true
	},
	 assignedDriver:{
       model:'RouteSchedule',
       unique: true
     },
	
	firstName:{
	    type: 'string',
	    required: true
	},

	lastName:{

	    type: 'string',

	    required: true
	},

	email:{

	    type: 'string',

	    email: true,

	    unique: true
	},
	encryptedPassword:{

	    type: 'string',

	    required: true

	}
	}
};

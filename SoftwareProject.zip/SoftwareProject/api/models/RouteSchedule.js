module.exports = {

	attributes: {
	
	id:{
	    type: 'integer',
		primaryKey: true,
	    // unique: true
	},


		 // bus: {
   //    model: 'bus',
   //    columnName: 'busId'
   //  },

	 // Driver: {
  //     collection:'Driver',
  //      via: 'assignedDriver'
  //    },
	// Route:{
 //      model:'Ticket',
 //      unique: true
 //    },

	destination:{

	    type: 'string',

	    required: true
	},

	source:{

	    type: 'string',

	    required: true
	},
	date:{

	    type: 'date',
		required:true
	},
		status:{

	    type: 'char',
		required:true
	},
		name:{

	    type: 'string',
		required:true
	},
		startingDate:{

	    type: 'date',
		required:true
	},
		endingDate:{

	    type: 'date',
		required:true
	},

	owner: {
		model: 'bus'
	}

	// Driver: {
 //      collection:'Driver',
 //      via: 'AssignedDriver'
 //    }
	// Route:{
 //      model:'Ticket',
 //      unique: true
 //    }
	}
};
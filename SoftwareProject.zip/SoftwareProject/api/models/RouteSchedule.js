module.exports = {

	attributes: {
	
	id:{
	    type: 'integer',
		primaryKey: true,
	    // unique: true
	},

	destination:{

	    type: 'string',

	    required: true
	},

	source:{

	    type: 'string',

	    required: true
	},
	date:{

	    type: 'date',
		required:true
	},
		status:{

	    type: 'char',
		required:true
	},
		name:{

	    type: 'string',
		required:true
	},
		startingDate:{

	    type: 'date',
		required:true
	},
		endingDate:{

	    type: 'date',
		required:true
	},
	 bus: {
      collection:'bus',
      via: 'assignedRouteSchedule'
    }
	// Driver: {
 //      collection:'Driver',
 //      via: 'AssignedDriver'
 //    }
	// Route:{
 //      model:'Ticket',
 //      unique: true
 //    }
	}
};
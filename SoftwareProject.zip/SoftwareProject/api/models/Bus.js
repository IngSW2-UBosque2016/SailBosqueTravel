
module.exports = {

	attributes: {
	
	// uuid:{
	// 	type:'int',
	// 	primarykey: true,
	// 	unique: true
	// },

	id:{
	    type: 'integer',
		primaryKey: true,
	    // unique: true
	},

	assignedRouteSchedule:{
      model:'routeSchedule',
      //columnName: 'idaa',
      index: true,
      unsigned: true,
      null: false
    },

	licensePlate:{
	    type: 'string',
	    unique: true
	},

	capacity:{

	    type: 'integer',

	    required: true
	},

	currentLatitude:{

	    type: 'float',

	    required: true
	},
	currentLongitude:{

	    type: 'float',
		required:true

	},
		soldSeats:{

	    type: 'integer',
		required:true

	},
		color:{

	    type: 'string',
		required:true

	},
		photo:{

	    type: 'string',
		required:true

	},
	
	}
};
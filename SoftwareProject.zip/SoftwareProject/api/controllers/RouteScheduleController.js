module.exports = {

registration: function(req,res){

    res.view();
},

create: function(req,res,next){


   RouteSchedule.create(req.params.all(), function routeScheduleCreated(err,user){

        if(err){
            return next(err);
        }
        else{

        	res.json({msj:'YEAH!!!'});
        }

    });
 }
 }

